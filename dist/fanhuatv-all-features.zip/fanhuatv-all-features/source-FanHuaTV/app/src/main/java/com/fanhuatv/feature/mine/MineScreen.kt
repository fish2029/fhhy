package com.fanhuatv.feature.mine

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.fanhuatv.feature.settings.SettingsViewModel
import com.fanhuatv.navigation.Routes
import com.fanhuatv.ui.theme.ACCENT_SCHEMES
import com.fanhuatv.ui.theme.Accent
import com.fanhuatv.ui.theme.BgCard
import com.fanhuatv.ui.theme.BgSurface
import com.fanhuatv.ui.theme.TextSecondary

/** 我的页（即设置页）：卡片式分组——我的内容 / 核心配置 / 安全调试 / 主题色彩 / 导航首页 / 系统。 */
@Composable
fun MineScreen(
    navController: NavController,
    vm: SettingsViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showHotUpdate by remember { mutableStateOf(false) }
    var showDanmaku by remember { mutableStateOf(false) }
    var showAiConfig by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // 头部：品牌标识
        Surface(color = BgSurface) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Accent,
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(Modifier, Alignment.Center) {
                        Text("繁华", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("繁华幻影手机版", color = com.fanhuatv.ui.theme.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("影视 · 直播 一站式", color = TextSecondary, fontSize = 12.sp)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ===== 1. 我的内容 =====
            GroupCard("我的内容") {
                NavRow(Icons.Filled.History, "观看历史", "接着上次继续看") {
                    navController.navigate(Routes.HISTORY)
                }
                NavRow(Icons.Filled.Favorite, "我的收藏", "收藏的影片都在这") {
                    navController.navigate(Routes.FAVORITE)
                }
            }

            // ===== 2. 核心配置 =====
            GroupCard("核心配置") {
                NavRow(Icons.Filled.Code, "PY 脚本管理", "导入 .py 自动注册数据源（优先于 JSON）") {
                    navController.navigate(Routes.PY_SCRIPT)
                }
                NavRow(Icons.Filled.Tv, "接口配置", "点播接口 / 直播源 / 多源线路") {
                    navController.navigate(Routes.CONFIG)
                }
                NavRow(Icons.Filled.Sync, "源热更新", "填 PY 脚本远程地址，改源不发包") {
                    showHotUpdate = true
                }
            }

            // ===== 播放 =====
            GroupCard("播放") {
                SwitchRow(Icons.Filled.Fullscreen, "退出播放自动变小窗", "按返回键进入悬浮小窗继续播放", ui.autoPip == true) { on ->
                    vm.updateUi { it.copy(autoPip = on) }
                }
                NavRow(Icons.Filled.Subtitles, "弹幕设置", "字号 / 速度 / 透明度 / 屏蔽词") {
                    showDanmaku = true
                }
            }

            // ===== AI 修源 =====
            GroupCard("AI 修源") {
                NavRow(Icons.Filled.BugReport, "AI 修源配置", "填 AI 接口地址和密钥，脚本报错一键让 AI 修") {
                    showAiConfig = true
                }
            }

            // ===== 3. 安全调试 =====
            GroupCard("安全调试") {
                NavRow(Icons.Filled.Security, "安全状态", "签名校验 / 防二次打包") {
                    navController.navigate(Routes.SECURITY)
                }
                NavRow(Icons.Filled.BugReport, "崩溃日志", "上次崩溃的完整堆栈，截图即可反馈") {
                    navController.navigate(Routes.CRASH_LOG)
                }
            }

            // ===== 4. 主题色彩 =====
            GroupCard("主题色彩") {
                // 外观模式：三段胶囊（跟随系统 / 浅色日间 / 深色夜间），切换即时生效
                SettingHeader(Icons.Filled.Palette, "外观模式", current = modeLabel(ui.themeMode))
                SegmentedCapsule(
                    options = listOf("system" to "跟随系统", "light" to "浅色日间", "dark" to "深色夜间"),
                    selected = ui.themeMode,
                    onSelect = { key -> vm.updateUi { it.copy(themeMode = key) } }
                )
                // 强调色：一排色点，选中的带勾，点击全局即时换色
                SettingHeader(Icons.Filled.ColorLens, "主题强调色", current = accentLabel(ui.accent ?: "purple"))
                AccentDotRow(
                    selected = ui.accent ?: "purple",
                    onSelect = { key -> vm.updateUi { it.copy(accent = key) } }
                )
                // 全局背景颜色：一排排色点直接点选（与文字颜色同款交互），切换即时生效
                SettingHeader(Icons.Filled.FormatColorFill, "全局背景颜色", current = bgLabel(ui.bgColor ?: "default"))
                BgColorDotRow(
                    selected = ui.bgColor ?: "default",
                    onSelect = { key -> vm.updateUi { it.copy(bgColor = key) } }
                )
                // 按钮样式：全局按钮/胶囊的圆角形态（方角/圆角/胶囊），切换即时生效
                OptionRow(Icons.Filled.SmartButton, "按钮样式", current = buttonStyleLabel(ui.buttonStyle ?: "capsule")) { close ->
                    DropdownItem("方角") { vm.updateUi { it.copy(buttonStyle = "square") }; close() }
                    DropdownItem("圆角") { vm.updateUi { it.copy(buttonStyle = "rounded") }; close() }
                    DropdownItem("胶囊") { vm.updateUi { it.copy(buttonStyle = "capsule") }; close() }
                }
                // 全局文字颜色：一排排色点直接点选（与强调色同款交互），切换即时生效
                SettingHeader(Icons.Filled.TextFields, "全局文字颜色", current = textColorLabel(ui.textColor ?: "white"))
                TextColorDotRow(
                    selected = ui.textColor ?: "white",
                    onSelect = { key -> vm.updateUi { it.copy(textColor = key) } }
                )
                Text(
                    "强调色、按钮样式、文字颜色、背景颜色、外观模式全部即时生效，切换不会中断浏览位置。",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(start = 56.dp, end = 16.dp, bottom = 10.dp)
                )
            }

            // ===== 5. 导航首页 =====
            GroupCard("导航首页") {
                OptionRow(Icons.Filled.ViewWeek, "底部导航栏形态", current = bottomBarLabel(ui.bottomBarStyle ?: "labeled")) { close ->
                    DropdownItem("图标+文字") { vm.updateUi { it.copy(bottomBarStyle = "labeled") }; close() }
                    DropdownItem("仅图标") { vm.updateUi { it.copy(bottomBarStyle = "icons") }; close() }
                }
                OptionRow(Icons.Filled.SwapVert, "滑动页面时底栏自动收起", current = if (ui.bottomBarAutoHide == true) "上滑折叠" else "常驻显示") { close ->
                    DropdownItem("常驻显示") { vm.updateUi { it.copy(bottomBarAutoHide = false) }; close() }
                    DropdownItem("上滑折叠") { vm.updateUi { it.copy(bottomBarAutoHide = true) }; close() }
                }
                SwitchRow(Icons.Filled.PhotoLibrary, "首页精选大图横幅", "顶部轮播大图", ui.homeBanner != false) { on ->
                    vm.updateUi { it.copy(homeBanner = on) }
                }
                OptionRow(Icons.Filled.GridView, "海报墙排布密度", current = columnsLabel(ui.posterColumns ?: 3)) { close ->
                    DropdownItem("疏松（2 列）") { vm.updateUi { it.copy(posterColumns = 2) }; close() }
                    DropdownItem("标准（3 列）") { vm.updateUi { it.copy(posterColumns = 3) }; close() }
                    DropdownItem("紧密（4 列）") { vm.updateUi { it.copy(posterColumns = 4) }; close() }
                }
                OptionRow(Icons.Filled.Subtitles, "海报下方信息显示", current = if (ui.posterInfo == "title") "仅标题" else "全部显示") { close ->
                    DropdownItem("全部显示") { vm.updateUi { it.copy(posterInfo = "all") }; close() }
                    DropdownItem("仅标题") { vm.updateUi { it.copy(posterInfo = "title") }; close() }
                }
                SwitchRow(Icons.Filled.History, "首页显示继续观看", "没看完的影片在首页接着看", ui.continueWatching != false) { on ->
                    vm.updateUi { it.copy(continueWatching = on) }
                }
            }

            // ===== 6. 系统 =====
            GroupCard("系统") {
                SwitchRow(Icons.Filled.Category, "智能分类", "站源自动归类：JAR内站点 / PY站点 / 音乐 / 短剧", ui.smartCategory) { on ->
                    vm.updateUi { it.copy(smartCategory = on) }
                }
                NavRow(Icons.Filled.Info, "关于", "版本信息 / 用户协议 / 隐私政策") {
                    navController.navigate(Routes.ABOUT)
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }

    // 源热更新弹窗：填远程地址 + 自动拉取开关，保存后可立即刷新
    if (showHotUpdate) {
        val savedUrl by vm.hotUpdateUrl.collectAsStateWithLifecycle()
        val savedAuto by vm.hotUpdateAuto.collectAsStateWithLifecycle()
        var urlInput by remember(showHotUpdate) { mutableStateOf(savedUrl) }
        var autoInput by remember(showHotUpdate) { mutableStateOf(savedAuto) }
        AlertDialog(
            onDismissRequest = { showHotUpdate = false },
            title = { Text("源热更新") },
            text = {
                Column {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("PY 脚本地址（网盘 / GitHub 直链）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = autoInput, onCheckedChange = { autoInput = it })
                        Spacer(Modifier.width(10.dp))
                        Text("启动时自动拉取最新脚本", fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "已导入过该地址的脚本会原位覆盖，站点注册不变，改源无需重新安装",
                        color = TextSecondary, fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveHotUpdateConfig(urlInput, autoInput)
                    if (urlInput.isNotBlank()) vm.runHotUpdate()
                    showHotUpdate = false
                }) { Text("保存并刷新") }
            },
            dismissButton = {
                TextButton(onClick = {
                    vm.saveHotUpdateConfig(urlInput, autoInput)
                    showHotUpdate = false
                }) { Text("仅保存") }
            }
        )
    }

    // 弹幕设置弹窗：字号 / 跨屏速度 / 透明度 / 屏蔽词
    if (showDanmaku) {
        var sizeInput by remember(showDanmaku) { mutableStateOf((ui.danmakuSize ?: 14).coerceIn(10, 24)) }
        var speedInput by remember(showDanmaku) { mutableStateOf((ui.danmakuSpeed ?: 9).coerceIn(5, 15)) }
        var alphaInput by remember(showDanmaku) { mutableStateOf((ui.danmakuAlpha ?: 100).coerceIn(20, 100)) }
        var blockInput by remember(showDanmaku) { mutableStateOf(ui.danmakuBlock ?: "") }
        AlertDialog(
            onDismissRequest = { showDanmaku = false },
            title = { Text("弹幕设置") },
            text = {
                Column {
                    Text("字号 ${sizeInput}sp", fontSize = 13.sp)
                    Slider(value = sizeInput.toFloat(), onValueChange = { sizeInput = it.toInt() }, valueRange = 10f..24f, steps = 6)
                    Text("跨屏速度 ${speedInput} 秒（越小越快）", fontSize = 13.sp)
                    Slider(value = speedInput.toFloat(), onValueChange = { speedInput = it.toInt() }, valueRange = 5f..15f, steps = 9)
                    Text("不透明度 $alphaInput%", fontSize = 13.sp)
                    Slider(value = alphaInput.toFloat(), onValueChange = { alphaInput = it.toInt() }, valueRange = 20f..100f, steps = 15)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = blockInput,
                        onValueChange = { blockInput = it },
                        label = { Text("屏蔽词（用逗号或顿号分隔）") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateUi { it.copy(danmakuSize = sizeInput, danmakuSpeed = speedInput, danmakuAlpha = alphaInput, danmakuBlock = blockInput.trim()) }
                    showDanmaku = false
                }) { Text("保存") }
            },
            dismissButton = {
                TextButton(onClick = { showDanmaku = false }) { Text("取消") }
            }
        )
    }

    // AI 修源配置弹窗：接口地址 / 密钥 / 模型名（模型可空，默认 gpt-3.5-turbo）
    if (showAiConfig) {
        val savedAiUrl by vm.aiUrl.collectAsStateWithLifecycle()
        val savedAiKey by vm.aiKey.collectAsStateWithLifecycle()
        val savedAiModel by vm.aiModel.collectAsStateWithLifecycle()
        var urlInput by remember(showAiConfig) { mutableStateOf(savedAiUrl) }
        var keyInput by remember(showAiConfig) { mutableStateOf(savedAiKey) }
        var modelInput by remember(showAiConfig) { mutableStateOf(savedAiModel) }
        AlertDialog(
            onDismissRequest = { showAiConfig = false },
            title = { Text("AI 修源配置") },
            text = {
                Column {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("AI 接口地址（OpenAI 兼容）") },
                        placeholder = { Text("https://api.xxx.com/v1") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text("接口密钥（API Key）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = modelInput,
                        onValueChange = { modelInput = it },
                        label = { Text("模型名（留空默认 gpt-3.5-turbo）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "配置好后，PY 脚本管理里诊断脚本报错时，可点「AI 试着修一下」自动修复",
                        color = TextSecondary, fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveAiConfig(urlInput, keyInput, modelInput)
                    showAiConfig = false
                }) { Text("保存") }
            },
            dismissButton = {
                TextButton(onClick = { showAiConfig = false }) { Text("取消") }
            }
        )
    }
}

private fun modeLabel(key: String): String = when (key) {
    "dark" -> "深色夜间"
    "light" -> "浅色日间"
    else -> "跟随系统"
}

private fun accentLabel(key: String): String = when (key) {
    "purple" -> "典雅紫"
    "blue" -> "深海蓝"
    "cyan" -> "湖水青"
    "pink" -> "绯红玫粉"
    "orange" -> "暖阳橙"
    "green" -> "松石绿"
    else -> textColorLabel(key)
}

private fun bottomBarLabel(key: String): String = when (key) {
    "icons" -> "仅图标"
    else -> "图标+文字"
}

private fun buttonStyleLabel(key: String): String = when (key) {
    "square" -> "方角"
    "rounded" -> "圆角"
    else -> "胶囊"
}

private fun textColorLabel(key: String): String = when (key) {
    "silver" -> "银灰"
    "red" -> "正红"
    "purered" -> "纯红"
    "crimson" -> "绯红"
    "rose" -> "玫红"
    "orange" -> "橙色"
    "tangerine" -> "橘红"
    "yellow" -> "金黄"
    "pureyellow" -> "纯黄"
    "lemon" -> "柠黄"
    "lime" -> "青柠"
    "green" -> "草绿"
    "puregreen" -> "纯绿"
    "forest" -> "深绿"
    "cyan" -> "青色"
    "teal" -> "湖绿"
    "sky" -> "天蓝"
    "azure" -> "湛蓝"
    "pureblue" -> "纯蓝"
    "indigo" -> "靛蓝"
    "purple" -> "紫色"
    "violet" -> "深紫"
    "magenta" -> "品红"
    "pink" -> "桃粉"
    "salmon" -> "珊瑚"
    "brown" -> "棕色"
    "wine" -> "酒红"
    else -> "纯白"
}

private fun bgLabel(key: String): String = when (key) {
    "default" -> "默认纯黑"
    "graphite" -> "石墨灰"
    "slate" -> "岩板灰"
    "charcoal" -> "炭灰"
    "navy" -> "深海军蓝"
    "steel" -> "钢蓝"
    "ocean" -> "深海蓝"
    "forest" -> "墨绿"
    "moss" -> "苔绿"
    "olive" -> "橄榄绿"
    "tealbg" -> "墨青"
    "coffee" -> "咖啡棕"
    "wine" -> "酒红"
    "aubergine" -> "茄紫"
    "plum" -> "深梅紫"
    "indigo" -> "深靛蓝"
    else -> key
}

private fun columnsLabel(columns: Int): String = when (columns) {
    2 -> "疏松"
    4 -> "紧密"
    else -> "标准"
}

/** 卡片式分组：圆角卡片 + 紫色组标题 */
@Composable
private fun GroupCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = BgCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(vertical = 6.dp)) {
            Text(
                title,
                color = Accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            content()
        }
    }
}

/** 行左侧的彩色小圆角图标（全局紫主题：淡紫底 + 紫图标） */
@Composable
private fun RowIcon(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .background(Accent.copy(alpha = 0.15f), RoundedCornerShape(9.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(17.dp))
    }
}

/** 带图标和右侧当前值的行头（配合胶囊/色点等展开控件用） */
@Composable
private fun SettingHeader(icon: ImageVector, title: String, current: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(14.dp))
        Text(title, color = com.fanhuatv.ui.theme.TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(current, color = Accent, fontSize = 13.sp)
    }
}

/** 三段式分段胶囊（外观模式），选中段紫底白字 */
@Composable
private fun SegmentedCapsule(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .background(Accent.copy(alpha = 0.10f), RoundedCornerShape(12.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { (key, label) ->
            val isSel = key == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (isSel) Accent else Color.Transparent)
                    .clickable { onSelect(key) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (isSel) Color.White else TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

/** 全局文字颜色色点选择器：与强调色同款交互，24 档分三排，选中的带勾 + 描边 */
@Composable
private fun TextColorDotRow(selected: String, onSelect: (String) -> Unit) {
    val keys = com.fanhuatv.ui.theme.TEXT_COLORS.keys.toList()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        keys.chunked(8).forEach { rowKeys ->
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                rowKeys.forEach { key ->
                    val isSel = key == selected
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(com.fanhuatv.ui.theme.TEXT_COLORS[key] ?: Color.White)
                            .border(
                                width = if (isSel) 2.dp else 0.dp,
                                color = if (isSel) Color.White.copy(alpha = 0.85f) else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { onSelect(key) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

/** 强调色色点选择器：与文字颜色同款交互，24 档分三排，选中的带勾 + 描边 */
@Composable
private fun AccentDotRow(selected: String, onSelect: (String) -> Unit) {
    val keys = ACCENT_SCHEMES.keys.toList()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        keys.chunked(8).forEach { rowKeys ->
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                rowKeys.forEach { key ->
                    val isSel = key == selected
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(ACCENT_SCHEMES[key]?.base ?: Color.White)
                            .border(
                                width = if (isSel) 2.dp else 0.dp,
                                color = if (isSel) Color.White.copy(alpha = 0.85f) else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { onSelect(key) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

/** 全局背景颜色色点选择器：与文字颜色同款交互，16 档分两排，选中的带勾 + 描边 */
@Composable
private fun BgColorDotRow(selected: String, onSelect: (String) -> Unit) {
    val keys = com.fanhuatv.ui.theme.BG_COLORS.keys.toList()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        keys.chunked(8).forEach { rowKeys ->
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                rowKeys.forEach { key ->
                    val isSel = key == selected
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(com.fanhuatv.ui.theme.BG_COLORS[key] ?: Color.Black)
                            .border(
                                width = if (isSel) 2.dp else 0.dp,
                                color = if (isSel) Color.White.copy(alpha = 0.85f) else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { onSelect(key) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun NavRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = com.fanhuatv.ui.theme.TextPrimary, fontSize = 15.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = TextSecondary, fontSize = 11.sp)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
    }
}

@Composable
private fun SwitchRow(icon: ImageVector, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = com.fanhuatv.ui.theme.TextPrimary, fontSize = 15.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = TextSecondary, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** 下拉选项行：点整行弹出菜单，选项用 DropdownItem 逐个写 */
@Composable
private fun OptionRow(
    icon: ImageVector,
    title: String,
    current: String,
    items: @Composable (close: () -> Unit) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(14.dp))
        Text(title, color = com.fanhuatv.ui.theme.TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(current, color = Accent, fontSize = 13.sp)
        Spacer(Modifier.width(4.dp))
        Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = TextSecondary)
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            items { expanded = false }
        }
    }
}

@Composable
private fun DropdownItem(label: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, onClick = onClick)
}
